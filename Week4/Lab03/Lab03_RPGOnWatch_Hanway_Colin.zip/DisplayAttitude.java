public interface DisplayAttitude {
	public void display();
}