public enum Encounter {
	Nothing,
	Squirrel,
	Goblin,
	Troll,
	Dragon
}