public interface OnWatch {
	public void observeEncounter(Encounter encounter);
}