public interface LongRest {
	public void stayAwake(OnWatch watcher);
	public void goToSleep(OnWatch watcher);
	public void somethingHappened();
}