public class ExceedsHitPoints extends RuntimeException {
    public ExceedsHitPoints(String message) {
        super(message);
    }
}
